from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello, world! \n This is just sample page. We can host any web application in place of this application")
